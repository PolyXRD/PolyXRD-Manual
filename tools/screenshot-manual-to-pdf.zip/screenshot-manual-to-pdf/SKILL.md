---
name: screenshot-manual-to-pdf
agent_created: true
description: Generate a professional Chinese software user manual as a PDF from existing UI screenshots, README, and Markdown docs. Use when the user asks for a "manual", "user guide", "usage instructions", or "PDF documentation" for a software project and screenshot assets are available.
---

# Screenshot Manual to PDF

## Overview

This skill produces a paginated, Chinese-language PDF manual for a desktop or web application by combining existing UI screenshots (e.g. acceptance shots, smoke-test captures) with structured explanatory text derived from README, CHANGELOG, and Markdown docs.

It uses Python + reportlab so the output is a real PDF (not a text outline or HTML page) with embedded PNG screenshots, tables, callout boxes, page numbers, and Chinese fonts from the Windows system font directory.

## When to Use

Trigger this skill when the user requests:

- "帮我设计这个项目的 Manual，pdf 版本"
- "生成一份带截图的使用手册 PDF"
- "软件使用说明 / 用户手册 / 操作手册 PDF"
- Updating an existing PDF manual for a new release version

Prerequisites:

- A set of PNG screenshots showing the UI (recommended 10–20 images)
- Source material describing features: README.md, CHANGELOG.md, quick-start docs, etc.
- A Python environment with `reportlab` and `Pillow` installed
- Windows TTF/TTC fonts available (e.g. `msyh.ttc`, `simhei.ttf`)

## Workflow

1. **Discover assets**
   - Locate screenshot directory (common names: `_accept_shots/`, `docs/manual/img/`, `screenshots/`)
   - Read README.md and any `*上手*.md`, `*manual*.md`, `*usage*.md` files for feature descriptions

2. **Plan the manual structure**
   - Typical chapters: 概述 → 安装/启动 → 界面导览 → 数据加载与预处理 → 核心功能 A → 核心功能 B → 报告/导出 → FAQ
   - Map each screenshot to a figure caption and chapter

3. **Generate the PDF**
   - Copy/adapt the bundled script `scripts/generate_manual.py`
   - Fill in title, version, date, chapter content, and screenshot filenames
   - Run the script with the project venv Python

4. **Verify**
   - Check file size and page count with `pypdf` or `PyMuPDF`
   - Render a few pages to PNG to confirm Chinese text and images appear correctly

## Using the Script

```bash
# Install dependencies
python -m pip install reportlab pillow pypdf pymupdf

# Adapt paths and content inside scripts/generate_manual.py, then run
python docs/manual/generate_manual.py
```

Key adaptation points in the script:

- `SHOTS`: directory containing PNG screenshots
- `OUTPUT`: destination PDF path (convention: `docs/manual/<Project>使用手册-v<version>.pdf`)
- `build_story()`: replace chapter text with project-specific content
- `add_shot()`: map screenshot filenames to captions

## Output Conventions

- PDF size: A4, 2 cm margins
- Fonts: Microsoft YaHei for body, SimHei for headings, footer in 9 pt gray
- Images: scaled to page width, max height capped to avoid overflow
- Figures: centered with caption "图 X-Y  描述"

## Resources

- `scripts/generate_manual.py` — reusable reportlab generator template
