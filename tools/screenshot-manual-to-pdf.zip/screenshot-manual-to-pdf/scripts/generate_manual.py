# -*- coding: utf-8 -*-
"""Generate PolyXRD v2.0.0 Chinese user manual PDF with embedded screenshots."""
import os
from datetime import datetime
from PIL import Image as PILImage

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import cm
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_JUSTIFY
from reportlab.platypus import (
    BaseDocTemplate, PageTemplate, Frame, Paragraph, Spacer,
    Image, Table, TableStyle, PageBreak, ListFlowable, ListItem
)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

# ---------------------------------------------------------------------------
# Font registration
# ---------------------------------------------------------------------------
pdfmetrics.registerFont(TTFont('YaHei', 'C:/Windows/Fonts/msyh.ttc'))
pdfmetrics.registerFont(TTFont('YaHeiBold', 'C:/Windows/Fonts/msyhbd.ttc'))
pdfmetrics.registerFont(TTFont('SimHei', 'C:/Windows/Fonts/simhei.ttf'))

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
ROOT = 'E:/TEMP/PolyXRD'
SHOTS = os.path.join(ROOT, '_accept_shots')
OUTPUT = os.path.join(ROOT, 'docs/manual/PolyXRD使用手册-v2.0.0.pdf')

# ---------------------------------------------------------------------------
# Styles
# ---------------------------------------------------------------------------
def make_styles():
    base = ParagraphStyle(
        'base', fontName='YaHei', fontSize=10.5, leading=16,
        textColor=colors.HexColor('#222222'), alignment=TA_JUSTIFY,
        spaceAfter=6
    )
    styles = {
        'title': ParagraphStyle(
            'title', parent=base, fontName='YaHeiBold', fontSize=26,
            leading=34, alignment=TA_CENTER, spaceAfter=18,
            textColor=colors.HexColor('#1a4f8b')
        ),
        'subtitle': ParagraphStyle(
            'subtitle', parent=base, fontSize=13, leading=20,
            alignment=TA_CENTER, textColor=colors.HexColor('#555555'),
            spaceAfter=60
        ),
        'h1': ParagraphStyle(
            'h1', parent=base, fontName='YaHeiBold', fontSize=18,
            leading=26, textColor=colors.HexColor('#1a4f8b'),
            spaceBefore=22, spaceAfter=10,
            borderWidth=0, borderColor=colors.HexColor('#1a4f8b'),
            borderPadding=0
        ),
        'h2': ParagraphStyle(
            'h2', parent=base, fontName='YaHeiBold', fontSize=14,
            leading=22, textColor=colors.HexColor('#2a6db5'),
            spaceBefore=16, spaceAfter=8
        ),
        'h3': ParagraphStyle(
            'h3', parent=base, fontName='YaHeiBold', fontSize=11.5,
            leading=18, textColor=colors.HexColor('#333333'),
            spaceBefore=12, spaceAfter=6
        ),
        'body': ParagraphStyle(
            'body', parent=base, alignment=TA_JUSTIFY, spaceAfter=6
        ),
        'caption': ParagraphStyle(
            'caption', parent=base, fontSize=9, leading=13,
            textColor=colors.HexColor('#666666'), alignment=TA_CENTER,
            spaceAfter=14
        ),
        'tip': ParagraphStyle(
            'tip', parent=base, fontSize=9.5, leading=14,
            textColor=colors.HexColor('#1a4f8b'),
            leftIndent=8, rightIndent=8,
            spaceBefore=6, spaceAfter=8
        ),
        'warn': ParagraphStyle(
            'warn', parent=base, fontSize=9.5, leading=14,
            textColor=colors.HexColor('#a04000'),
            leftIndent=8, rightIndent=8,
            spaceBefore=6, spaceAfter=8
        ),
        'code': ParagraphStyle(
            'code', parent=base, fontName='Courier', fontSize=9,
            leading=13, textColor=colors.HexColor('#333333'),
            backColor=colors.HexColor('#f4f4f4'), leftIndent=8,
            spaceBefore=4, spaceAfter=4
        ),
        'toc': ParagraphStyle(
            'toc', parent=base, fontSize=11, leading=18,
            leftIndent=12, spaceAfter=2
        ),
        'toc1': ParagraphStyle(
            'toc1', parent=base, fontName='YaHeiBold', fontSize=12,
            leading=20, leftIndent=0, spaceAfter=2
        ),
    }
    return styles

STYLES = make_styles()

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
def P(text, style='body'):
    return Paragraph(text.replace('\n', '<br/>'), STYLES[style])


def H1(text):
    return Paragraph(text, STYLES['h1'])


def H2(text):
    return Paragraph(text, STYLES['h2'])


def H3(text):
    return Paragraph(text, STYLES['h3'])


def tip(text):
    return Table([[Paragraph(text, STYLES['tip'])]],
                 colWidths=[16 * cm],
                 style=TableStyle([
                     ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#eef5fd')),
                     ('LEFTPADDING', (0, 0), (-1, -1), 8),
                     ('RIGHTPADDING', (0, 0), (-1, -1), 8),
                     ('TOPPADDING', (0, 0), (-1, -1), 6),
                     ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
                     ('LINEBELOW', (0, 0), (-1, -1), 3, colors.HexColor('#2a6db5')),
                 ]))


def warn(text):
    return Table([[Paragraph(text, STYLES['warn'])]],
                 colWidths=[16 * cm],
                 style=TableStyle([
                     ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#fdf3ee')),
                     ('LEFTPADDING', (0, 0), (-1, -1), 8),
                     ('RIGHTPADDING', (0, 0), (-1, -1), 8),
                     ('TOPPADDING', (0, 0), (-1, -1), 6),
                     ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
                     ('LINEBELOW', (0, 0), (-1, -1), 3, colors.HexColor('#d35400')),
                 ]))


def add_shot(story, filename, caption, max_width=16 * cm):
    path = os.path.join(SHOTS, filename)
    if not os.path.exists(path):
        story.append(P(f'[截图缺失: {filename}]', 'caption'))
        return
    with PILImage.open(path) as im:
        w, h = im.size
    aspect = h / w
    img_width = max_width
    img_height = img_width * aspect
    # Limit height to avoid overly tall pages
    max_height = 22 * cm
    if img_height > max_height:
        img_height = max_height
        img_width = img_height / aspect
    story.append(Spacer(1, 0.2 * cm))
    story.append(Image(path, width=img_width, height=img_height))
    story.append(P(f'图 {caption}', 'caption'))


def make_table(data, col_widths=None, header=True):
    t = Table(data, colWidths=col_widths, repeatRows=1 if header else 0)
    style = [
        ('FONTNAME', (0, 0), (-1, -1), 'YaHei'),
        ('FONTSIZE', (0, 0), (-1, -1), 9),
        ('LEADING', (0, 0), (-1, -1), 13),
        ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
        ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
        ('LEFTPADDING', (0, 0), (-1, -1), 5),
        ('RIGHTPADDING', (0, 0), (-1, -1), 5),
        ('TOPPADDING', (0, 0), (-1, -1), 4),
        ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
    ]
    if header:
        style += [
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1a4f8b')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'YaHeiBold'),
        ]
    t.setStyle(TableStyle(style))
    return t


# ---------------------------------------------------------------------------
# Document setup with page numbers
# ---------------------------------------------------------------------------
def footer(canvas, doc):
    canvas.saveState()
    canvas.setFont('YaHei', 9)
    canvas.setFillColor(colors.HexColor('#888888'))
    canvas.drawRightString(A4[0] - 2 * cm, 1.2 * cm, f'{doc.page}')
    canvas.drawString(2 * cm, 1.2 * cm, 'PolyXRD v2.0.0 使用手册')
    canvas.restoreState()


# ---------------------------------------------------------------------------
# Content
# ---------------------------------------------------------------------------
def build_story():
    s = []

    # Cover
    s.append(Spacer(1, 6 * cm))
    s.append(P('PolyXRD 使用手册', 'title'))
    s.append(P('X 射线粉末衍射物相分析 · 结构精修 · 多引擎集成', 'subtitle'))
    s.append(P('版本 v2.0.0 &nbsp;|&nbsp; 2026 年 9 月', 'subtitle'))
    s.append(Spacer(1, 2 * cm))
    s.append(tip('<b>说明：</b>本手册截图来自 PolyXRD v2.0.0 中文界面，部分功能（如深色主题、多语言）在不同主题/语言下布局一致，仅文案语言不同。'))
    s.append(PageBreak())

    # TOC
    s.append(H1('目录'))
    toc_items = [
        ('第 1 章　软件概述', 'toc1'),
        ('第 2 章　安装、启动与数据库挂载', 'toc1'),
        ('第 3 章　主界面与数据视图', 'toc1'),
        ('第 4 章　数据加载与预处理', 'toc1'),
        ('第 5 章　峰检测与物相分析', 'toc1'),
        ('第 6 章　结构精修', 'toc1'),
        ('第 7 章　CIF 浏览器与 3D 结构可视化', 'toc1'),
        ('第 8 章　批量处理与格式转换', 'toc1'),
        ('第 9 章　报告与项目管理', 'toc1'),
        ('第 10 章　界面个性化（语言 / 主题）', 'toc1'),
        ('第 11 章　基本原理', 'toc1'),
        ('第 12 章　常见问题与故障排查', 'toc1'),
    ]
    for text, style in toc_items:
        s.append(P(text, style))
    s.append(PageBreak())

    # -----------------------------------------------------------------------
    # Chapter 1
    # -----------------------------------------------------------------------
    s.append(H1('第 1 章　软件概述'))
    s.append(H2('1.1 PolyXRD 是什么'))
    s.append(P(
        'PolyXRD 是一款面向材料学、化学、晶体学研究的 Windows 桌面 X 射线粉末衍射（XRD）'
        '数据分析软件。它将“加载原始谱图 → 预处理 → 峰检测 → 多物相定性检索 → Rietveld 结构精修'
        ' → 晶胞精修 → 全谱拟合 → 出报告”整条工作流集成在统一的 PySide6 (Qt6) 图形界面中，'
        '支持中文、英文、日文三语言切换。'
    ))
    s.append(P(
        '<b>核心工作流：</b>数据加载 → 谱图预处理 → 峰检测 → 物相检索匹配 → 勾选物相 → '
        'Rietveld / Le Bail 结构精修 → 报告输出。'
    ))

    s.append(H2('1.2 主要功能模块'))
    s.append(make_table([
        ['模块', '功能要点'],
        ['数据处理', '多格式加载（.xy/.txt/.csv/.dat/.mdi/.raw/.xrdml/.json 等）、背景扣除（SNIP / 多项式 / 小波）、平滑（Savitzky-Golay / FFT / Whittaker-Eilers）、Kα2 剥离、归一化、角度裁剪、格式互转'],
        ['峰检测与拟合', '二阶导数 + PV 拟合自动找峰，SNR ≥ 2 自适应阈值；支持 pseudo-Voigt / Pearson VII / Split-PV 单峰拟合'],
        ['物相分析', '多库检索（内置库 / COD 无机物 / COD 全库 / PDF2-2004 / 合并）、元素周期表过滤、FoM 加权互斥匹配、COD 在线检索、候选物相勾选与 CIF 导出'],
        ['结构精修', '内置快速引擎、GSAS-II、MAUD、FullProf、powerxrd 多引擎；快速精修与分步精修向导双路径；支持 Le Bail 晶胞精修与指标化'],
        ['可视化与报告', 'CIF 浏览器、3D 晶体结构视图、主谱/残差双画布、报告预览与 PDF/CSV 导出、.polyxrd 项目保存与恢复'],
    ]))
    s.append(Spacer(1, 0.3 * cm))
    s.append(tip(
        '<b>设计取向：</b>PolyXRD 的目标是用一条龙离线工作流覆盖常规实验室分析需求；'
        '与 Match!、JADE、FullProf Suite、MAUD、GSAS-II 等专业软件可互相配合使用，'
        '本软件可直接生成/导出它们可读的数据与控制文件。'
    ))

    s.append(H2('1.3 系统要求'))
    s.append(P(
        '操作系统：Windows 10 / 11 x64；内存：建议 8 GB 以上（处理大峰表或多相精修时 16 GB 更佳）；'
        '硬盘：安装包约 250 MB，如需挂载完整 COD 无机物内嵌库需额外约 1.2 GB。'
    ))
    s.append(PageBreak())

    # -----------------------------------------------------------------------
    # Chapter 2
    # -----------------------------------------------------------------------
    s.append(H1('第 2 章　安装、启动与数据库挂载'))
    s.append(H2('2.1 三种发行形态'))
    s.append(make_table([
        ['形态', '适用人群', '说明'],
        ['Setup 安装包 (.exe)', '普通用户（推荐）', '双击安装到本机，开始菜单生成快捷方式，卸载干净'],
        ['便携版 Portable (.zip)', '免安装 / U 盘场景', '解压即用，运行目录内 PolyXRD.exe，不写注册表'],
        ['PyInstaller 单文件 exe', '快速分发 / 完全离线', '内置离线 COD 数据库，拷贝到任意 Windows x64 机器直接运行'],
    ]))

    s.append(H2('2.2 安装与首次启动'))
    s.append(P(
        '1. 下载 <code>PolyXRD-Setup-v2.0.0.exe</code>（Windows x64）。<br/>'
        '2. 双击安装，默认路径为 <code>C:\\Program Files\\PolyXRD\\</code>。<br/>'
        '3. 安装完成后从开始菜单或桌面快捷方式启动 <code>PolyXRD.exe</code>。'
    ))
    s.append(warn(
        '<b>注意：</b>从 v0.10.0 起，主程序（安装包 / 便携包）<b>不再内置任何数据库</b>，'
        '三个数据库各自独立打包、独立下载、独立挂载。单文件 exe 除外。'
    ))

    s.append(H2('2.3 挂载衍射数据库'))
    s.append(P(
        '首次使用物相检索前，请通过菜单 <b>数据库 → 外挂数据库管理…</b> 挂载至少一个衍射数据库。'
        '对话框中每个槽位都标明了应导入的文件名与下载包名称，按提示选择对应 .sqlite 文件即可，'
        '导入后立即生效，无需重启。'
    ))
    add_shot(s, '10_db_manager.png', '2-1　数据库管理器：三库槽位独立挂载/卸载，状态灯、记录数、体积一目了然')
    s.append(P(
        '三库说明：<br/>'
        '• <b>COD 无机物库</b>：71,199 物相，日常推荐，瘦身索引式（362 MB）不含内嵌 CIF，'
        'CIF 由本地 <code>cod/cif</code> 目录或 COD 在线接口按需读取。<br/>'
        '• <b>COD 全库索引</b>：113,223 条目，覆盖更大化合物空间。<br/>'
        '• <b>PDF2-2004</b>：163,834 物相，ICDD 版权数据库，需用户自行取得正版授权后挂载。'
    ))
    s.append(tip(
        '<b>小技巧：</b>一个库都不装也能使用软件内置的 106 种常见参考物相；'
        '只挂载一个库即可进行检索，其他槽位留空不影响使用。'
    ))
    s.append(PageBreak())

    # -----------------------------------------------------------------------
    # Chapter 3
    # -----------------------------------------------------------------------
    s.append(H1('第 3 章　主界面与数据视图'))
    s.append(H2('3.1 主窗口布局'))
    s.append(P(
        '主窗口采用“顶部工具栏 + 标签页 + 左侧面板 + 右侧停靠窗口”布局。'
        '顶部工具栏集中了打开/保存、预处理、峰检测、物相检索、精修、导出等高频入口；'
        '左侧参数面板随当前标签页切换；右侧物相列表显示当前已勾选物相。'
    ))
    add_shot(s, '00_main_window.png', '3-1　主窗口总览：工具栏、数据页签、左侧面板、中央谱图区、右侧物相列表')
    s.append(make_table([
        ['区域', '内容'],
        ['顶部工具栏', '打开/保存、扣背景、平滑、剥 Kα2、峰检测、Search/Match、Profile Fitting、Rietveld 精修、精修向导、COD 检索、导出、数据库管理等'],
        ['左侧参数面板', '当前页签的参数（波长、背景方法、峰检测阈值、精修引擎等）'],
        ['中央标签页', '数据 / 物相分析 / 结构精修 / 报告 四个主工作区'],
        ['右侧停靠窗口', '物相列表（显示已勾选物相，右键可导出 CIF / 查看详情）'],
        ['状态栏', '精修状态、最佳匹配物相、当前语言与波长信息'],
    ]))

    s.append(H2('3.2 数据视图'))
    s.append(P(
        '切换到“数据”页签即可查看原始/预处理后的衍射谱。中央画布基于 PyQtGraph，'
        '支持滚轮以光标为中心缩放、左键拖拽平移、工具栏 Home 键一键复位到数据全览。'
    ))
    add_shot(s, '01_data_view.png', '3-2　数据视图：加载样品后的衍射谱，右侧为预处理与峰检测参数面板')
    s.append(tip(
        '<b>交互提示：</b>若加载后峰位整体偏移，请检查左侧面板“波长”参数是否与实验条件一致；'
        '默认 Cu Kα1 为 1.5406 Å。'
    ))
    s.append(PageBreak())

    # -----------------------------------------------------------------------
    # Chapter 4
    # -----------------------------------------------------------------------
    s.append(H1('第 4 章　数据加载与预处理'))
    s.append(H2('4.1 支持格式'))
    s.append(P(
        'PolyXRD 支持多种常见 XRD 数据格式，可通过菜单 <b>文件 → 打开</b> 或直接将文件拖放到窗口加载。'
    ))
    s.append(make_table([
        ['格式', '说明'],
        ['.txt / .csv / .dat / .xy / .xye', '两列或三列文本（2θ-强度 或 2θ-强度-误差），自动跳过 # / ! 注释行，utf-8-sig 免疫 BOM'],
        ['.xrdml', 'PANalytical XML 标准格式'],
        ['.raw', 'Bruker RAW 格式（RAW2）'],
        ['.mdi', 'JADE 专用格式'],
        ['.json', 'PolyXRD 项目或导出的结构化谱图'],
        ['.prf', 'GSAS 格式'],
    ]))

    s.append(H2('4.2 预处理流水线'))
    s.append(P('建议按以下顺序处理原始谱图，以获得更准确的峰位与强度：'))
    s.append(make_table([
        ['步骤', '入口', '作用与原理'],
        ['① 扣背景', '左侧面板“背景方法”+“执行背景扣除”', '去除空气散射、荧光、样品台散射等缓变背景。SNIP 算法对晶面密集、背景起伏复杂的谱最稳健'],
        ['② 平滑', '左侧面板“平滑方法”', 'Savitzky-Golay 卷积在去噪的同时保留峰形；窗口宽度 11 点为常用起点'],
        ['③ 剥 Kα2', '工具栏“Kα2 剥离”', '按 Kα2/Kα1 ≈ 0.5 强度比逐点剥除 Kα2 贡献，使后续检索基于单色峰位'],
        ['④ 归一化 / 裁剪', '左侧面板', '强度归一到 0–100 或最大值 100；裁掉低信噪比区段'],
    ]))
    s.append(tip(
        '<b>提示：</b>低 2θ 空气散射背景是 wR 偏高的常见根因之一，精修前建议先充分扣除背景。'
    ))

    s.append(H2('4.3 峰检测'))
    s.append(P(
        '点击工具栏“峰检测”或在左侧面板调节阈值后点击“检测峰”。默认以相对高度 5%、最小间距 0.5°、'
        '突出度 1% 自动找峰；勾选“高精度（背景扣除 + 亚步长）”可识别重叠肩峰并细化峰位。'
    ))
    add_shot(s, '02_peak_finding.png', '4-1　峰检测结果：谱图上竖虚线标记检出峰位，右下峰表列出 2θ、d、强度、FWHM 等信息')
    s.append(tip(
        '<b>峰太多</b>（噪声误检）→ 提高最小峰高/最小距离；<b>峰太少</b>（弱峰漏检）→ 降低阈值或提高灵敏度。'
    ))
    s.append(PageBreak())

    # -----------------------------------------------------------------------
    # Chapter 5
    # -----------------------------------------------------------------------
    s.append(H1('第 5 章　峰检测与物相分析'))
    s.append(H2('5.1 检索流程'))
    s.append(P(
        '切换到“物相分析”页签，确认已进行峰检测，然后点击工具栏“传统 Search/Match”或“Profile Fitting”。'
        '软件将检出峰位（d-I 列表）与数据库标准卡片比对，按 <b>FoM（Figure of Merit）</b> 排序输出候选物相。'
    ))
    s.append(H2('5.2 数据库源选择'))
    s.append(make_table([
        ['数据源', '规模', '适用场景'],
        ['内置库', '106 / 118 种常见物相', '快速演示、教学、无数据库时'],
        ['COD 无机物库', '71,199 无机物相', '日常推荐，d-I 预计算 + Hanawalt 预筛，速度最快'],
        ['COD 全库', '113,223 条 CIF 索引', '需要覆盖全化合物空间'],
        ['内置 + COD 全库合并', '组合检索', '高召回检索'],
        ['PDF2-2004', '163,834 物相', '有 ICDD 正版授权时（卡片信息最全）'],
    ]))

    s.append(H2('5.3 元素过滤'))
    s.append(P(
        '若已知样品含有的元素（如 EDS 结果），点击左侧面板“元素过滤（周期表）”打开交互式周期表。'
        '支持四种语义：必有（全部命中）、含有（至少一个）、可能（仅放宽允许池）、没有（排除）。'
    ))
    add_shot(s, '11_element_filter.png', '5-1　元素周期表过滤器：四种语义配色，一键将轻元素 O/C/H/N/S 设为含有')
    s.append(tip(
        '<b>技巧：</b>未勾选元素默认并入“没有”形成闭环；点击右上角“轻元素设为含有”可一键将 O/C/H/N/S 加入允许池。'
    ))

    s.append(H2('5.4 Search/Match 结果'))
    s.append(P(
        '识别结果以列表形式展示，含 FoM、矿物名、化学式、空间群等信息。点击候选物相可在谱图上叠加参考峰：'
        '绿色实线表示已匹配峰，红色虚线表示未匹配峰。'
    ))
    add_shot(s, '03_phase_view.png', '5-2　内置库检索结果：候选列表按 FoM 排序，谱图叠加标准峰位竖线')
    add_shot(s, '03b_phase_view_cod.png', '5-3　COD 无机物库检索结果：命中 COD 编号与复杂化学式')
    s.append(P(
        '勾选可信物相后，物相列表会同步到主窗口右侧停靠窗与精修页“已勾选物相”列表。'
        '右键物相可导出 CIF，作为外部程序（GSAS-II / MAUD / FullProf）的初始结构。'
    ))

    s.append(H2('5.5 COD 在线检索'))
    s.append(P(
        '若本地库无果，可点击工具栏“COD 检索”按元素与谱图联网查询 Crystallography Open Database。'
        '检索到的 CIF 可直接导入为精修初始模型。'
    ))
    s.append(PageBreak())

    # -----------------------------------------------------------------------
    # Chapter 6
    # -----------------------------------------------------------------------
    s.append(H1('第 6 章　结构精修'))
    s.append(H2('6.1 Rietveld 精修原理（30 秒版）'))
    s.append(P(
        'Rietveld 法不用单个峰的积分强度，而是用结构模型逐点计算整张衍射谱，并与实测谱做最小二乘拟合。'
        '可精修的量包括标度因子（→物相含量）、晶胞参数（→峰位）、峰形参数、零点偏移、背景多项式等。'
    ))
    s.append(P(
        '拟合质量用 R 因子衡量。v2.0.0 起 <b>Rwp / Rexp / GOF</b> 一律基于统计权（<code>stat_weights=poisson</code>）；'
        '显式改用单位权时 Rexp/GOF 无物理意义，界面会显示“不可解读”。'
    ))
    s.append(warn(
        '<b>注意：</b>默认加权 wR 与旧单位权 wR 不可比。跨版本比较 wR 时必须声明口径。'
    ))

    s.append(H2('6.2 精修页快速精修'))
    s.append(P(
        '切换到“结构精修”页签，确认右栏“已勾选物相”列表非空；在“精修控制”面板选择引擎、策略、循环数、峰形、背景，'
        '然后点击“开始精修”。完成后上方面板显示实验/模拟对比谱，下方残差条与上方 X 轴联动。'
    ))
    add_shot(s, '04_refinement_view.png', '6-1　结构精修页：主谱/残差 5:1 分栏、右侧控制/结果/含量/外部引擎面板')
    s.append(make_table([
        ['引擎', '性质', '说明'],
        ['auto（推荐）', '自动选择', '按本机安装情况在 GSAS-II / MAUD / FullProf / 内置间择优'],
        ['builtin', '内置快速拟合', '零依赖、秒级完成；基于 CIF |F|² 参考峰 + 各向同性晶胞缩放，用于快速验证物相组合'],
        ['gsas2', 'GSAS-II 桥接', '调用本机 GSAS-II 安装，出标准 Rietveld 结果与 wt%'],
        ['maud', 'MAUD 批处理', '生成 .par + .xye，批处理跑完回读结果'],
        ['fullprof', 'FullProf 批处理', '自动生成 .dat/.pcr → 调用 fp2k 精修 → 回读 Rwp/Rexp/Rp/GoF 与各相 R_Bragg/晶胞/含量'],
        ['powerxrd', '轻量开源引擎', '轻量备选'],
    ]))

    s.append(H2('6.3 精修向导（分步式）'))
    s.append(P(
        '工具栏“精修向导”打开分步对话框：数据 → 物相 → 参数 → 预览 → 执行，共五步。'
        '支持模板参数、CIF 导入与 COD 检索，适合新手或复杂多相体系。'
        '快速精修与分步向导是两条独立路径，结果互不覆盖。'
    ))
    add_shot(s, '14_refinement_wizard.png', '6-2　分步精修向导第一步：确认数据信息与精修范围')

    s.append(H2('6.4 外部精修程序'))
    s.append(P(
        '精修页右栏底部为三行外部程序面板（状态灯 / 路径 / 浏览 / 检测 / 启动）。'
        '点击“检测”可自动探测本机安装；若探测失败，可“浏览…”手动指定可执行文件。配置保存在 '
        '<code>~/.polyxrd/external_tools.json</code>，重启后保留。'
    ))
    s.append(tip(
        '<b>工作目录：</b>外部程序运行目录固定为 <code>~/.polyxrd/external_runs/&lt;时间戳&gt;/</code>，'
        '内含输入/输出文件，便于核查或手动精修。'
    ))
    s.append(PageBreak())

    # -----------------------------------------------------------------------
    # Chapter 7
    # -----------------------------------------------------------------------
    s.append(H1('第 7 章　CIF 浏览器与 3D 结构可视化'))
    s.append(H2('7.1 CIF 浏览器'))
    s.append(P(
        '菜单 <b>数据库 → CIF 浏览器</b> 可浏览内置库或已挂载库中的物相条目，查看矿物名、化学式、空间群、晶胞参数。'
        '选中条目后点击“加载”可在右侧查看结构详情，或导出 CIF。'
    ))
    add_shot(s, '06_cif_browser.png', '7-1　CIF 浏览器：按矿物名/化学式/空间群搜索，右侧显示晶胞参数')

    s.append(H2('7.2 3D 晶体结构视图'))
    s.append(P(
        '对于带结构数据的物相，CIF 浏览器或物相列表右键可选择“查看 3D 结构”。'
        '视图自动按空间群展开非对称单元，以原子球模型展示晶胞。'
    ))
    add_shot(s, '06b_structure_view_3d.png', '7-2　3D 晶体结构视图：自动展开非对称单元，支持旋转/缩放查看原子排布')
    s.append(PageBreak())

    # -----------------------------------------------------------------------
    # Chapter 8
    # -----------------------------------------------------------------------
    s.append(H1('第 8 章　批量处理与格式转换'))
    s.append(H2('8.1 批量精修'))
    s.append(P(
        '菜单 <b>工具 → 批量精修</b> 可对文件夹内全部数据文件依次使用当前已选物相进行精修。'
        '每个文件独立使用物相副本，结果可导出 CSV 汇总。'
    ))
    add_shot(s, '13_batch_refine.png', '8-1　批量精修对话框：选择数据文件夹、引擎与迭代轮数，一键顺序处理')

    s.append(H2('8.2 谱图格式转换'))
    s.append(P(
        '菜单 <b>文件 → 谱图格式转换</b> 支持 xy / txt / dat / csv / mdi / raw / xrdml / json 共 8 种格式互转。'
        '选择源文件与目标格式后，点击“转换”即可输出新文件；转换结果不会自动载入主窗口。'
    ))
    add_shot(s, '12_format_convert.png', '8-2　谱图格式转换：选择源文件、目标格式、输出路径后一键转换')
    s.append(PageBreak())

    # -----------------------------------------------------------------------
    # Chapter 9
    # -----------------------------------------------------------------------
    s.append(H1('第 9 章　报告与项目管理'))
    s.append(H2('9.1 报告页'))
    s.append(P(
        '切换到“报告”页签可实时预览精修报告：包含精修质量指标（wR / GOF / 质量等级）、'
        '物相列表（化学式 / 质量分数 / 晶胞参数 / 晶胞体积）。可导出 JSON（机器可读）或 PDF。'
    ))
    add_shot(s, '05_report_view.png', '9-1　报告页：生成报告预览并选择 json/pdf 等格式导出')

    s.append(H2('9.2 项目保存与恢复'))
    s.append(P(
        '菜单 <b>文件 → 保存项目 / 打开项目</b> 使用 .polyxrd 文件记录：数据文件路径、处理参数、峰列表、'
        '物相勾选集、精修结果。换机或重开软件后可完整还原工作现场。'
    ))
    s.append(PageBreak())

    # -----------------------------------------------------------------------
    # Chapter 10
    # -----------------------------------------------------------------------
    s.append(H1('第 10 章　界面个性化（语言 / 主题）'))
    s.append(H2('10.1 多语言切换'))
    s.append(P(
        'PolyXRD 支持简体中文、English、日本語三语言。点击状态栏语言按钮或在菜单中切换，'
        '界面会整页重翻译（包括停靠面板、工具栏提示），无需重启，下次启动自动沿用。'
        'v2.0.0 三语翻译键集已对齐，缺键不再漏出裸键名。'
    ))
    add_shot(s, '30_lang_en.png', '10-1　英文界面：工具栏、面板、峰表全部英文化')
    add_shot(s, '31_lang_ja.png', '10-2　日文界面：菜单、参数、提示均显示日语')

    s.append(H2('10.2 深色主题'))
    s.append(P(
        '菜单 <b>视图 → 主题</b> 可在白天/深色主题间切换。深色主题下谱图、面板、工具栏均自动适配暗色调。'
    ))
    add_shot(s, '20_theme_after_toggle.png', '10-3　深色主题下的数据视图')
    s.append(PageBreak())

    # -----------------------------------------------------------------------
    # Chapter 11
    # -----------------------------------------------------------------------
    s.append(H1('第 11 章　基本原理'))
    s.append(H2('11.1 Bragg 定律与衍射位置'))
    s.append(P(
        '晶面间距 d 的晶面族在入射角 θ 处产生相长干涉：2d·sinθ = n·λ。'
        '测得一系列 2θ 峰位、已知波长 λ，即可反推各晶面的 d 值序列——这是物相“指纹”比对的物理基础。'
    ))
    s.append(H2('11.2 衍射强度'))
    s.append(P(
        '各 (hkl) 衍射的积分强度由结构因子 |F<sub>hkl</sub>|²（原子种类与坐标决定）、多重性因子 m、'
        '洛伦兹-偏振因子 LP、温度因子共同决定。强度分布是第二重指纹，也是 Rietveld 定量相分析的依据。'
    ))
    s.append(H2('11.3 检索匹配（Search/Match）'))
    s.append(P(
        '传统流程 = Hanawalt（以最强 3 峰的 d 值组合查索引）+ Fink（8 强峰）+ 逐峰容差匹配与强度相关打分。'
        'PolyXRD 对数据库预先计算 d-I 峰表并建立强峰索引，检索时先粗筛再精排（FoM），从而在十万级卡片上实现秒级响应。'
    ))
    s.append(H2('11.4 背景与峰形'))
    s.append(P(
        'SNIP 背景算法对谱反复做“LLS 求最小 → clipping”的尺度递归，把快变峰“削”掉只留慢变背景。'
        '峰形用 pseudo-Voigt（Gaussian 与 Lorentzian 线性组合，混合系数 η）描述；'
        '峰宽随角度的变化用 Caglioti 公式 FWHM² = U·tan²θ + V·tanθ + W。'
    ))
    s.append(H2('11.5 v2.0.0 精修指标口径'))
    s.append(P(
        'v2.0.0 修复了此前 Rexp/GOF 错误：统一使用统计权（poisson）计算 Rwp/Rexp/Rp/χ²/GOF，'
        '使指标与标准定义一致。builtin 引擎给出的是 Le Bail 级全谱拟合结果，'
        '其 wt% 标注为 mass 或 relative，严格质量分数只在带结构的相上启用。'
    ))
    s.append(PageBreak())

    # -----------------------------------------------------------------------
    # Chapter 12
    # -----------------------------------------------------------------------
    s.append(H1('第 12 章　常见问题与故障排查'))
    qa = [
        ('Q1：物相检索没有结果/结果很差？',
         '按顺序检查：① 是否已挂载数据库；② 峰检测是否合理（过多/过少都会毁掉匹配）；'
         '③ 是否应开启元素过滤；④ 波长是否正确；⑤ 尝试换数据库（内置 → COD 无机物 → 合并）。'),
        ('Q2：builtin 精修 wR 高达 50~90%？',
         'builtin 是内置 Le Bail 级快速拟合引擎，不精修原子坐标/占位/ADP，用于快速验证物相组合，wR 偏高属正常现象。'
         '定量结论请改用 gsas2 / maud / fullprof。'),
        ('Q3：外部程序状态灯是红色？',
         '点该行“检测”自动探测；仍不行则“浏览…”手动指定（FullProf 选 fp2k.exe；GSAS-II 选其自带 python.exe；'
         'MAUD 选安装根目录或 java.exe）。配置会持久化。'),
        ('Q4：精修不收敛/发散？',
         '常见原因：物相初始晶胞错误；标度因子量级差太多；背景方法不当；数据噪声过大。'
         '建议分步放开参数（先 scale+bg，再 cell，再峰形）比一次全放开稳健。'),
        ('Q5：谱图 X 轴显示范围不对？',
         'v0.15 起图谱自动收缩到数据范围；滚轮缩放、左键拖拽平移、工具栏 Home 复位。'),
        ('Q6：外部精修后文件在哪里？',
         '<code>C:\\Users\\&lt;用户名&gt;\\.polyxrd\\external_runs\\&lt;程序_时间戳&gt;\\</code>，内含输入/输出文件。'),
        ('Q7：双击 PolyXRD.exe 没反应？',
         'PolyXRD 是单实例程序：若已有实例在跑，双击会把已有窗口拉到前台。'
         '若仍无法启动，命令行执行 <code>PolyXRD.exe --diagnose</code> 生成诊断报告，'
         '或查看 <code>~/.polyxrd/logs/startup-*.log</code>。'),
        ('Q8：PDF2-2004 库如何获得？',
         'PDF2-2004 为 ICDD 商业数据库，PolyXRD 不随附、不转发。持有正版授权的用户可准备 PDF2_2004.sqlite '
         '并在数据库管理器中作为 PDF2 槽位导入。'),
    ]
    for q, a in qa:
        s.append(H3(q))
        s.append(P(a))

    s.append(Spacer(1, 1 * cm))
    s.append(P(
        '<b>联系与许可</b><br/>'
        'PolyXRD 学术研究与教学免费使用；商业用途需单独书面授权。'
        '完整条款见 LICENSE / LICENSE-CN。联系邮箱：sshztx@outlook.com'
    ))
    s.append(Spacer(1, 1 * cm))
    s.append(P('— 手册结束 · PolyXRD v2.0.0 —', 'caption'))

    return s


# ---------------------------------------------------------------------------
# Build
# ---------------------------------------------------------------------------
def main():
    story = build_story()
    doc = BaseDocTemplate(
        OUTPUT,
        pagesize=A4,
        leftMargin=2 * cm, rightMargin=2 * cm,
        topMargin=2 * cm, bottomMargin=2 * cm,
    )
    frame = Frame(
        doc.leftMargin, doc.bottomMargin + 1 * cm,
        doc.width, doc.height - 1.2 * cm,
        id='normal'
    )
    template = PageTemplate(id='all', frames=frame, onPage=footer)
    doc.addPageTemplates([template])
    doc.build(story)
    print(f'Generated: {OUTPUT}')


if __name__ == '__main__':
    main()
